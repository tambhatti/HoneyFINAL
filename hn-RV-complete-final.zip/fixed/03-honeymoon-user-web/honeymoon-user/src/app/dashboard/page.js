'use client';
import { useApi } from '../../hooks/useApi';
import UserService from '../../lib/services/user.service';
import { useUserAuth } from '../../context/auth';
import { useState } from 'react';
import Link from 'next/link';

// Fresh Figma assets
const imgStar = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Emblema_del_Quinto_Centenario.svg/200px-Emblema_del_Quinto_Centenario.svg.png";
const imgVenueImg = "https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=800&q=80";
const imgPhotoImg = "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800&q=80";
const imgBeautyImg = "https://images.unsplash.com/photo-1522673607200-164d1b6ce486?w=800&q=80";

const imgCateringImg = "https://images.unsplash.com/photo-1555244162-803834f70033?w=800&q=80";
const imgFlowersImg = "https://images.unsplash.com/photo-1490750967868-88aa4f44baee?w=800&q=80";
const imgJewelryImg = "https://images.unsplash.com/photo-1515562141589-67f0d99e2954?w=800&q=80";
const imgDecorImg = "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=800&q=80";

const featuredVendorsList = [
  { id: 1, name: 'The Wedding Atelier', contact: 'James Milner', rating: 4.8, reviews: 12, img: imgVenueImg },
  { id: 2, name: 'Hearts Aligned', contact: 'Sarah Parker', rating: 4.7, reviews: 531, img: imgPhotoImg },
  { id: 3, name: 'Pearl Promise', contact: 'Anthony Ross', rating: 4.9, reviews: 12, img: imgBeautyImg },
  { id: 4, name: 'Velvet Vows', contact: 'Emily Stone', rating: 4.6, reviews: 45, img: imgDecorImg },
];

const categoryList = [
  { name: 'Catering', count: 348, img: imgCateringImg },
  { name: 'Flowers', count: 731, img: imgFlowersImg },
  { name: 'Jewelry', count: 238, img: imgJewelryImg },
  { name: 'Decoration', count: 156, img: imgDecorImg },
  { name: 'Photography', count: 420, img: imgPhotoImg },
];

const stats = [
  { label: 'Active Bookings', value: '3', change: '+1 this week', icon: '📋', color: '#174a37' },
  { label: 'Vendors Shortlisted', value: '12', change: '4 new matches', icon: '🏛', color: '#CFB383' },
  { label: 'Budget Used', value: '42%', change: 'AED 84K / 200K', icon: '💰', color: '#1a1a1a' },
  { label: 'Days to Wedding', value: '187', change: 'June 15, 2026', icon: '💍', color: '#174a37' },
];

const bookings = [
  { vendor: 'Al Habtoor Palace', type: 'Venue', date: 'Jun 15, 2026', status: 'Confirmed', amount: 'AED 45,000', img: imgVenueImg },
  { vendor: 'Studio Lumière', type: 'Photography', date: 'Jun 15, 2026', status: 'Pending', amount: 'AED 8,500', img: imgPhotoImg },
  { vendor: 'Glamour Touch', type: 'Beauty', date: 'Jun 14, 2026', status: 'Confirmed', amount: 'AED 3,200', img: imgBeautyImg },
];

const aiMatches = [
  { name: 'Emirates Palace Ballroom', cat: 'Venue', rating: 4.9, match: 98, img: imgVenueImg },
  { name: 'Capture by Nadia', cat: 'Photography', rating: 4.8, match: 95, img: imgPhotoImg },
  { name: 'Floral Emirates', cat: 'Decoration', rating: 4.7, match: 92, img: imgBeautyImg },
];

const budgetCats = [
  { cat: 'Venue', budgeted: 80000, spent: 45000 },
  { cat: 'Photography', budgeted: 15000, spent: 8500 },
  { cat: 'Beauty', budgeted: 8000, spent: 3200 },
  { cat: 'Catering', budgeted: 60000, spent: 0 },
];

function StatusBadge({ status }) {
  const c = { Confirmed: 'bg-green-100 text-green-700', Pending: 'bg-amber-100 text-amber-700', Cancelled: 'bg-red-100 text-red-700' };
  return <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${c[status] || ''}`}>{status}</span>;
}

export default function DashboardHome() {
  const { user } = useUserAuth();
  const { data, loading } = useApi(UserService.getHome);
  const featuredVendors = data?.featuredVendors || [];
  const categories = data?.categories || [];
  return (
    <div className="w-full max-w-[1200px] min-w-0 pb-6">
      {/* Welcome banner */}
      <div className="bg-[#174a37] rounded-2xl p-5 sm:p-6 md:p-8 mb-6 sm:mb-8 relative overflow-hidden min-w-0">
        <div className="absolute right-4 top-4 w-24 h-24 bg-white/5 rounded-full" />
        <div className="absolute right-16 top-12 w-16 h-16 bg-[#CFB383]/10 rounded-full" />
        <p className="text-white/50 text-sm uppercase tracking-wider">Good Morning ✨</p>
        <h1 className="font-baskerville text-[26px] sm:text-[32px] md:text-[42px] text-[#CFB383] mt-1 mb-3 break-words">
          Rashed &amp; Fatima&apos;s Wedding
        </h1>
        <p className="text-white/60 text-sm md:text-base max-w-[480px] mb-6">
          Your AI planner found 4 new vendor matches based on your preferences.
        </p>
        <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
          <Link href="/dashboard/ai-planner"
            className="bg-[#CFB383] text-white text-sm font-medium px-6 py-2.5 rounded-[10px] hover:bg-[#B8A06E] transition-colors text-center w-full sm:w-auto">
            Open AI Planner ✦
          </Link>
          <Link href="/dashboard/vendors"
            className="border border-white/20 text-white text-sm font-medium px-6 py-2.5 rounded-[10px] hover:bg-white/10 transition-colors text-center w-full sm:w-auto">
            Browse Vendors
          </Link>
          <Link href="/dashboard/getting-started"
            className="text-white/40 text-sm hover:text-white/60 transition-colors text-center sm:text-left py-1">
            Setup checklist →
          </Link>
        </div>
      </div>

      {/* Search bar — Figma 02 Home */}
      <div className="flex gap-2 mb-6 min-w-0 items-stretch sm:items-center">
        <div className="flex-1 min-w-0 flex items-center gap-3 bg-white border border-gray-200 rounded-full px-4 sm:px-5 min-h-[52px] h-[52px]">
          <svg className="w-5 h-5 text-gray-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><circle cx="11" cy="11" r="8" strokeWidth="2"/><path d="M21 21l-4.35-4.35" strokeWidth="2" strokeLinecap="round"/></svg>
          <input type="text" placeholder="Search vendors, services..." className="flex-1 min-w-0 bg-transparent text-sm outline-none text-[#1a1a1a] placeholder:text-gray-400" />
        </div>
        <Link href="/dashboard/search" className="w-[52px] h-[52px] shrink-0 bg-[#174a37] rounded-full flex items-center justify-center" aria-label="Search">
          <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M3 7h2v2H3V7zm0 4h2v2H3v-2zm0 4h2v2H3v-2zm4-8h14v2H7V7zm0 4h14v2H7v-2zm0 4h14v2H7v-2z"/></svg>
        </Link>
      </div>

      {/* Plan Your Wedding Budget — Figma 02 Home */}
      <div className="bg-[#CFB383] rounded-[20px] p-6 md:p-8 mb-8 text-center">
        <h2 className="font-baskerville text-[24px] md:text-[28px] text-[#1a1a1a] mb-2">Plan Your Wedding Budget</h2>
        <p className="text-[#1a1a1a]/70 text-sm mb-5">Quick questions. Instant wedding cost estimate.</p>
        <Link href="/budget-estimation"
          className="inline-flex items-center gap-2 bg-[#174a37] text-white text-sm font-medium px-8 py-3.5 rounded-full hover:bg-[#1a5c45] transition-colors w-full max-w-[400px] justify-center">
          Estimate Budget
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 17L17 7M17 7H7M17 7v10" /></svg>
        </Link>
      </div>

      {/* Featured Vendors — Figma 02 Home */}
      <div className="mb-8">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between mb-4 min-w-0">
          <h2 className="font-baskerville text-lg sm:text-[22px] text-[#1a1a1a]">Featured Vendors</h2>
          <Link href="/dashboard/vendors" className="text-[#CFB383] text-sm font-medium hover:underline shrink-0">See all</Link>
        </div>
        <div className="flex gap-4 overflow-x-auto overscroll-x-contain touch-pan-x pb-2 scrollbar-hide -mx-2 px-2">
          {featuredVendorsList.map(v => (
            <Link key={v.id} href={`/dashboard/vendors/${v.id}`}
              className="shrink-0 w-[155px] group">
              <div className="h-[102px] rounded-lg overflow-hidden mb-2">
                <img src={v.img} alt={v.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              </div>
              <p className="font-medium text-sm text-[#1a1a1a] truncate">{v.name}</p>
              <p className="text-xs text-gray-500 mt-0.5 flex items-center gap-1">
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                {v.contact}
              </p>
              <div className="flex items-center gap-1 mt-0.5">
                {[...Array(5)].map((_,i) => (
                  <svg key={i} className={`w-3 h-3 ${i < Math.floor(v.rating) ? 'text-amber-400' : 'text-gray-200'}`} fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                ))}
                <span className="text-xs text-gray-400 ml-0.5">{v.reviews}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Categories — Figma 02 Home */}
      <div className="mb-8">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between mb-4 min-w-0">
          <h2 className="font-baskerville text-lg sm:text-[22px] text-[#1a1a1a]">Categories</h2>
          <Link href="/vendors" className="text-[#CFB383] text-sm font-medium hover:underline shrink-0">See all</Link>
        </div>
        <div className="flex gap-4 overflow-x-auto overscroll-x-contain touch-pan-x pb-2 scrollbar-hide -mx-2 px-2">
          {categoryList.map(cat => (
            <Link key={cat.name} href={`/vendors/category/${cat.name.toLowerCase()}`}
              className="shrink-0 w-[138px] h-[188px] rounded-lg overflow-hidden relative group">
              <img src={cat.img} alt={cat.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 p-4">
                <p className="text-white font-medium text-base">{cat.name}</p>
                <p className="text-white/70 text-xs">{cat.count} vendors</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(({ label, value, change, icon }) => (
          <div key={label} className="bg-white rounded-2xl border border-[rgba(184_154_105_/_0.2)] p-4 md:p-6 shadow-[0_0_30px_rgba(0_0_0_/_0.04)] min-w-0">
            <div className="flex items-center justify-between mb-3 gap-2 min-w-0">
              <span className="text-xl shrink-0">{icon}</span>
              <span className="text-[#CFB383] text-[10px] uppercase tracking-wider shrink-0">Now</span>
            </div>
            <p className="font-baskerville text-[28px] md:text-[36px] text-[#1a1a1a] tabular-nums break-words">{value}</p>
            <p className="text-black/50 text-xs md:text-sm mt-0.5 break-words">{label}</p>
            <p className="text-[#174a37] text-xs mt-1.5 break-words">{change}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Bookings */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-[rgba(184_154_105_/_0.2)] shadow-[0_0_30px_rgba(0_0_0_/_0.04)]">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between p-4 sm:p-5 md:p-6 border-b border-[rgba(184_154_105_/_0.1)] min-w-0">
            <h2 className="font-baskerville text-lg sm:text-[22px] text-[#1a1a1a]">Upcoming Bookings</h2>
            <Link href="/dashboard/bookings" className="text-[#CFB383] text-sm hover:underline shrink-0">View all →</Link>
          </div>
          <div className="divide-y divide-[rgba(184_154_105_/_0.08)]">
            {bookings.map(b => (
              <Link key={b.vendor} href="/dashboard/bookings/1"
                className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4 p-4 md:p-5 hover:bg-[#faf7f0] transition-colors group min-w-0">
                <div className="flex items-center gap-4 min-w-0 flex-1">
                  <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0">
                    <img src={b.img} alt={b.vendor} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-[#1a1a1a] text-sm truncate">{b.vendor}</p>
                    <p className="text-black/40 text-xs mt-0.5">{b.type} · {b.date}</p>
                  </div>
                </div>
                <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-2 sm:text-right shrink-0 w-full sm:w-auto pt-2 sm:pt-0 border-t border-[rgba(184_154_105_/_0.06)] sm:border-0">
                  <StatusBadge status={b.status} />
                  <p className="text-[#1a1a1a] text-sm font-medium sm:mt-1 tabular-nums">{b.amount}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* AI Matches */}
        <div className="bg-white rounded-2xl border border-[rgba(184_154_105_/_0.2)] shadow-[0_0_30px_rgba(0_0_0_/_0.04)]">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between p-4 sm:p-5 md:p-6 border-b border-[rgba(184_154_105_/_0.1)] min-w-0">
            <h2 className="font-baskerville text-lg sm:text-[22px] text-[#1a1a1a]">AI Matches</h2>
            <span className="text-[#CFB383] text-xs px-2 py-1 bg-[#F5F5EF] rounded-full shrink-0 w-fit">✦ 4 New</span>
          </div>
          <div className="divide-y divide-[rgba(184_154_105_/_0.08)]">
            {aiMatches.map(v => (
              <Link key={v.name} href="/dashboard/vendors/1"
                className="flex items-center gap-3 p-4 hover:bg-[#faf7f0] transition-colors group">
                <div className="w-11 h-11 rounded-xl overflow-hidden shrink-0">
                  <img src={v.img} alt={v.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-[#1a1a1a] text-sm truncate">{v.name}</p>
                  <p className="text-black/40 text-xs">{v.cat}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <img src={imgStar} alt="★" className="w-3 h-3 object-contain" />
                    <span className="text-xs text-black/50">{v.rating}</span>
                  </div>
                </div>
                <span className="bg-[#174a37] text-white text-xs px-2 py-0.5 rounded-full shrink-0">{v.match}%</span>
              </Link>
            ))}
          </div>
          <div className="p-4">
            <Link href="/dashboard/ai-planner"
              className="w-full flex items-center justify-center gap-2 bg-[#F5F5EF] text-[#174a37] text-sm font-medium py-2.5 rounded-[10px] hover:bg-[#e8dfc5] transition-colors">
              ✦ See All AI Matches
            </Link>
          </div>
        </div>
      </div>

      {/* Budget overview */}
      <div className="bg-white rounded-2xl border border-[rgba(184_154_105_/_0.2)] shadow-[0_0_30px_rgba(0_0_0_/_0.04)] p-5 md:p-6">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between mb-6 min-w-0">
          <h2 className="font-baskerville text-lg sm:text-[22px] text-[#1a1a1a]">Budget Overview</h2>
          <Link href="/dashboard/budget" className="text-[#CFB383] text-sm hover:underline shrink-0">Manage →</Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {budgetCats.map(({ cat, budgeted, spent }) => {
            const pct = Math.round((spent / budgeted) * 100);
            return (
              <div key={cat}>
                <div className="flex justify-between mb-1.5">
                  <span className="text-sm font-medium text-[#1a1a1a]">{cat}</span>
                  <span className="text-xs text-black/40">{pct}%</span>
                </div>
                <div className="h-1.5 bg-[#F5F5EF] rounded-full overflow-hidden">
                  <div className="h-full bg-[#CFB383] rounded-full" style={{ width: `${pct}%` }} />
                </div>
                <div className="flex justify-between mt-1.5">
                  <span className="text-xs text-black/40">AED {spent.toLocaleString()}</span>
                  <span className="text-xs text-black/20">/ {(budgeted / 1000).toFixed(0)}K</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
